This tool is designed to help parser development. 

Install the dependencies using requirements.txt:
$ pip3 install -r requirements.txt

Steps to run the program:
$ python3 testbench_runner.py --logs "resource/eventfile.txt" --extractor "resource/fortinet-fortigate-syslog.yaml"

It requires two arguments :
 a. --logs which takes a file with logs to be parsed. Each log event should separated by a new line. Please refer sample file "eventfile.txt" under resource folder. File should be passed as argument with correct relative path or absolute path as per convenience.
 b. --extractor which takes the extractor/parser file in yaml format. Please refer sample file "fortinet-fortigate-syslog.yaml" under resource folder. File should be passed as argument with correct relative path or absolute path as per convenience.
 
This version of Test Bench works with python 3.6
