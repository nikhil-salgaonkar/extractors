import argparse
import os
import yaml
import sys
path_cwd = os.getcwd()
sys.path.append(path_cwd)
from parser_fixed_RE import execute

msg = "Parser TestBench"

def is_valid_file(parser, arg):
    if not os.path.exists(arg):
        parser.error("The file %s does not exist!" % arg)
    else:
        return open(arg, 'r')  # return an open file handle


parser = argparse.ArgumentParser(description=msg)
parser.add_argument("--logs", dest="log_file", required=True, help = "path to log file",
                    metavar="FILE",type=lambda x: is_valid_file(parser, x))
parser.add_argument("--extractor", dest="extractor_file", required=True, help = "path to extractor file",
                     metavar="FILE", type=lambda x: is_valid_file(parser, x))                    
args = parser.parse_args()
logs = args.log_file.readlines()
args.log_file.close()
parser = dict()
parser = yaml.safe_load(args.extractor_file.read())
args.extractor_file.close()
execute(logs, parser)